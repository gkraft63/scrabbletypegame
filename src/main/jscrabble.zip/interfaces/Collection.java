package jscrabble.interfaces;

import jscrabble.ScrabblePiece;

public interface Collection {

    ScrabblePiece getPieceAt(int x, int y);

    void removePiece(ScrabblePiece piece);

    boolean setPieceAt(int x, int y, ScrabblePiece piece);

}
