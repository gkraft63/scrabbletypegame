package jscrabble;

import java.util.Properties;

class JavaSystemImpl extends JavaSystem {

    private Properties systemProperties;

    public JavaSystemImpl() {
    }

}
