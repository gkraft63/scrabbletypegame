package jscrabble;

public class LicenseReaderListener {

}
