package jscrabble;

import java.awt.*;

public interface RankTable {

    void setBean(ScrabbleBean bean);

    void addRank(String player, int score, String opponent);

    boolean isShowing();

    void setShowing(boolean show, Component frameResolver);

}
