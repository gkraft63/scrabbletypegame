package jscrabble.cawt;

import java.awt.*;

public interface CComponent {

    Component getComponent();

}
