package jscrabble;

public class RuntimeContext {

}
