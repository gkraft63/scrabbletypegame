package jscrabble;
import jscrabble.Scrabble;
public class Main {

    public static void main(String[] args) {
        Scrabble.main(args);


    }
}
