package jscrabble;

public class Square {

    private final int wordMultiplier;

    private final int letterMultiplier;

    public Square(int wordMultiplier, int letterMultiplier) {
        this.wordMultiplier = wordMultiplier;
        this.letterMultiplier = letterMultiplier;
    }

    public int getLetterMultiplier() {
        return letterMultiplier;
    }

    public int getWordMultiplier() {
        return wordMultiplier;
    }
}
