package jscrabble.exceptions;

public class EmptyBagException extends RuntimeException {

    public EmptyBagException() {
    }

}
